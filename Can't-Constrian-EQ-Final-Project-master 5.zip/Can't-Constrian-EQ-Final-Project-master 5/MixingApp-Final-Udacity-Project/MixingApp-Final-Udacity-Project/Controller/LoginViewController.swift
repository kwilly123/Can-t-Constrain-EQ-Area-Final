//
//  LoginViewController.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-14.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import UIKit
import Firebase
import GoogleSignIn

class LoginViewController: UIViewController {
    
    var userID: String?
    var databaseRef: DatabaseReference!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        GIDSignIn.sharedInstance()?.presentingViewController = self
        GIDSignIn.sharedInstance()?.delegate = self
        activityIndicator.isHidden = true
        print("USER ID: \(String(describing: userID))")
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        activityIndicator.isHidden = false
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.destination is ProjectSelectViewController {
            let projectSelectVC = segue.destination as? ProjectSelectViewController
            projectSelectVC?.userID = userID
        }
    }
    
    func errorMessage(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}

extension LoginViewController: GIDSignInDelegate {
    
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        activityIndicator.isHidden = false
        activityIndicator.startAnimating()
        if let error = error {
            activityIndicator.stopAnimating()
            if (error as NSError).code == GIDSignInErrorCode.hasNoAuthInKeychain.rawValue {
                errorMessage(title: "Error", message: "The user has not signed in before or they have since signed out. Error: \(error.localizedDescription)")
            } else {
                print("\(error.localizedDescription)")
                errorMessage(title: "Error", message: "Error, reason: \(error.localizedDescription)")
            }
            return
        }
        
        NotificationCenter.default.post(name: Notification.Name("SuccessfulSignInNotification"), object: nil, userInfo: nil)
        
        guard let authentication = user.authentication else { return }
        let credential = GoogleAuthProvider.credential(withIDToken: authentication.idToken, accessToken: authentication.accessToken)
        
        Auth.auth().signIn(with: credential) { (user, error) in
            
            if error != nil {
                self.errorMessage(title: "Error", message: "Failed to log user in, reason: \(error?.localizedDescription ?? "")")
            }
            
            
            print("User signed into Firebase.")
            
            self.databaseRef = Database.database().reference()
            
            self.databaseRef.child("user_profiles").child((user?.user.uid)!).observeSingleEvent(of: .value) { (snapshot) in
                let snapshot = snapshot.value as? NSDictionary
                
                if (snapshot == nil) {
                    self.databaseRef.child("user_profiles").child((user?.user.uid)!).child("name").setValue(user?.user.displayName)
                    self.databaseRef.child("user_profiles").child((user?.user.uid)!).child("email").setValue(user?.user.email)
                } else {
                    self.activityIndicator.stopAnimating()
                    self.userID = user?.user.uid
                    self.performSegue(withIdentifier: "project", sender: nil)
                }
            }
            
        }
        
        
    }
}
