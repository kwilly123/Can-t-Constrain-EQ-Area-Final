//
//  SetupKnobs.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-21.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation
import UIKit

extension TracksViewController {
    
    //MARK: SETUP KNOBS
    
    func setupKnobs() {
        knob1.renderer.pointerLayer.strokeColor = UIColor.yellow.cgColor
        knob1.minimumValue = 20
        knob1.maximumValue = 400
        knob2.renderer.pointerLayer.strokeColor = UIColor.systemPink.cgColor
        knob2.minimumValue = 401
        knob2.maximumValue = 2000
        knob3.renderer.pointerLayer.strokeColor = UIColor.orange.cgColor
        knob3.minimumValue = 2001
        knob3.maximumValue = 8000
        knob4.renderer.pointerLayer.strokeColor = UIColor.systemTeal.cgColor
        knob4.minimumValue = 8001
        knob4.maximumValue = 20000
        
        knob5.renderer.pointerLayer.strokeColor = UIColor.yellow.cgColor
        knob5.minimumValue = -96
        knob5.maximumValue = 24
        knob6.renderer.pointerLayer.strokeColor = UIColor.systemPink.cgColor
        knob6.minimumValue = -96
        knob6.maximumValue = 24
        knob7.renderer.pointerLayer.strokeColor = UIColor.orange.cgColor
        knob7.minimumValue = -96
        knob7.maximumValue = 24
        knob8.renderer.pointerLayer.strokeColor = UIColor.systemTeal.cgColor
        knob8.minimumValue = -96
        knob8.maximumValue = 24
        
        knob1.bringSubviewToFront(knob1ValueLabel)
        knob2.bringSubviewToFront(knob2ValueLabel)
        knob3.bringSubviewToFront(knob3ValueLabel)
        knob4.bringSubviewToFront(knob4ValueLabel)
        knob5.bringSubviewToFront(knob5ValueLabel)
        knob6.bringSubviewToFront(knob6ValueLabel)
        knob7.bringSubviewToFront(knob7ValueLabel)
        knob8.bringSubviewToFront(knob8ValueLabel)
    }
    
}
