//
//  ScheduleAudioFiles.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-21.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation

extension TracksViewController {
    
    func scheduleFilesToStart() {
        DispatchQueue.global(qos: .background).async {
            for (index, audioPlayer) in self.audioPlayers.enumerated() {
                if let file = self.filesArray[index] {
                    audioPlayer?.scheduleFile(file, at: nil, completionHandler: nil)
                    print(file)
                } else {
                    print("Audio File nil")
                }
            }
        }
    }
    
    func scheduleFiles() {
        DispatchQueue.global(qos: .background).async {
            print("AUDIO PLAYERS: \(self.audioPlayers)")
            print("FILES: \(self.filesArray)")
            for (index, file) in self.filesArray.enumerated() {
                if let file = file {
                    self.audioPlayers[index]?.scheduleFile(file, at: nil, completionHandler: nil)
                    print("AUDIO PLAYER SCHEDULED VOLUME: \(self.audioPlayers[index]?.volume ?? 0)")
                    print("AUDIO PLAYER SCHEDULED PAN: \(self.audioPlayers[index]?.pan ?? 0)")
                    print("INDEX: \(index)")
                } else {
                    print("could not schedule audio file.")
                }
            }
        }
    }
    
}
